CS21120 Assignment 1: Concordance
Owain Jones <odj@aber.ac.uk>

I'm putting this up on GitHub to back it up.

To run:
	java -cp ./bin uk.ac.aber.dcs.odj.concordance.gui.MainWindow